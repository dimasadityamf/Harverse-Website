$(document).ready(function() {
    $('.icon-menu').click(function() {
        $('.icon-menu').toggleClass('bx-x')
        $('.menu').toggleClass('active')
    })
})